# By VenonSabio

#Imports
import os
import pyautogui
import time
import mouse
from os.path import dirname, abspath

#Atributos
numero = 0
strnumero = '0'
script_path = abspath(dirname(__file__))
endcounter = 0

print("Programa iniciado!")
print('Pressione Ctrl-C no console para sair.')

os.chdir(script_path)


def passouVef():
    try:
        location = pyautogui.locateOnScreen('notification.png')
        if location is not None:
            print("Encontrou!!")
            exit()
    except Exception as e:
        pass

def writeNumber(number):
    global strnumero
    if numero < 10:
        strnumero = str('000' + str(number))
        pyautogui.write(strnumero, interval = 0.05)
    elif numero < 100:
        strnumero = str('00' + str(numero))
        pyautogui.write(strnumero, interval = 0.05)
    elif numero < 1000:
        strnumero = str('0' + str(number))
        pyautogui.write(strnumero, interval = 0.05)
    else:
        strnumero = str(number)
        pyautogui.write(strnumero, interval = 0.05)

def incrementNum():
    global numero

    for i in range(5):

        writeNumber(numero)

        print(strnumero)
        pyautogui.press('enter')
        numero += 1

        passouVef()
        time.sleep(.5)
        passouVef()
        
    time.sleep(3)
    passouVef()



# Main

try:
    while True:
        if endcounter == 3:
            break

        os.startfile(r'C:\Program Files (x86)\Steam\steam.exe')

        time.sleep(14)

        try:
            location = pyautogui.locateCenterOnScreen('familyshare.png')
            if location is not None:
                pyautogui.moveTo(location)
            time.sleep(.5)
            mouse.click('left')
            pyautogui.moveTo(759, 81)

            time.sleep(1)
            incrementNum()
            passouVef()

            os.system("taskkill /f /im  steam.exe")
            time.sleep(3)

        except Exception as e:
            os.system("taskkill /f /im  steam.exe")
            time.sleep(3)
            endcounter += 1
            pass


except KeyboardInterrupt:
    print('\n')